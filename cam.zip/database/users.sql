-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 14, 2018 at 11:58 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `category` text NOT NULL,
  `amount` int(10) NOT NULL,
  `name` text NOT NULL,
  `note` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `balance` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`category`, `amount`, `name`, `note`, `date`, `balance`) VALUES
('vehicle', 100, '', 'petrol', '2018-06-13', 5000),
('food', 500, '', 'hotel', '2018-06-13', 4500),
('home', 500, '', 'dish bill', '2018-06-13', 4000),
('recharge', 399, '', 'jio', '2018-06-13', 3601),
('transfer', 500, '', 'paytm transfer', '2018-06-13', 3101),
('other', 100, '', 'phone', '2018-06-13', 3001),
('home', 100, 'santhosh', '100', '2018-06-13', 2901);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `frommsg` varchar(11) NOT NULL,
  `tomsg` varchar(11) NOT NULL,
  `message` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`frommsg`, `tomsg`, `message`, `date`) VALUES
('santhosh', 'saideep', 'hello', '0000-00-00'),
('saideep', 'santhosh', 'hii', '0000-00-00'),
('saideep', 'santhosh', 'hii', '2018-06-14');

-- --------------------------------------------------------

--
-- Table structure for table `regusers`
--

CREATE TABLE `regusers` (
  `name` varchar(20) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `income` bigint(10) NOT NULL,
  `balance` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regusers`
--

INSERT INTO `regusers` (`name`, `mail`, `password`, `income`, `balance`) VALUES
('hadd', 'sadas@fa', 'hadd', 500, 500),
('saideep', 'saideep@gmail.com', 'saideep', 5000, 5000),
('santhosh', 'santhosh@gmail.com', 'santhosh', 5100, 2901);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `name` varchar(11) NOT NULL,
  `taskname` varchar(30) NOT NULL,
  `time` time NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`name`, `taskname`, `time`, `date`) VALUES
('santhosh', 'fee', '02:02:00', '2018-06-13'),
('santhosh', 'school', '13:01:00', '2018-06-13'),
('santhosh', 'games', '16:01:00', '2018-06-13'),
('santhosh', 'fee', '10:10:00', '2018-06-14'),
('santhosh', 'games', '09:00:00', '2018-06-13'),
('santhosh', 'payments ', '05:00:00', '2018-06-13'),
('santhosh', 'payments ', '05:00:00', '2018-06-13'),
('santhosh', 'payments ', '05:00:00', '2018-06-13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `regusers`
--
ALTER TABLE `regusers`
  ADD PRIMARY KEY (`income`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `mail` (`mail`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
