<?php
$currentdate = date('m-d-Y');
echo "The Current Date is: $currentdate";
?>
