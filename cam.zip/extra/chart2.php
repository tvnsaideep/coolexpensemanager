<?php


  $food=0;$vehicle=0;$travel=0;$home=0;$elec=0;$rec=0;$fee=0;$tr=0;$other=0;
$name=$_SESSION['username'];
$conn=new mysqli("localhost","root","","users") or die("connectiong error".$conn->connect_error);
$myquery=mysqli_query($conn,"select * from expenses where name='$name'and date >= DATE_SUB(CURDATE(),INTERVAL 1 MONTH)");
if($myquery)
{
  while($row=mysqli_fetch_assoc($myquery))
{
  if($row['category']=='food')
  {
    $food=$food + $row['amount'];
  }
  elseif ($row['category']=='vehicle') {
    $vehicle=$vehicle+$row['amount'];
  }
  elseif ($row['category']=='home') {
    $home=$home+$row['amount'];
  }
  elseif ($row['category']=='recharge') {
    $rec=$rec+$row['amount'];
  }
  elseif ($row['category']=='electricity') {
    $elec=$elec+$row['amount'];
  }
  elseif ($row['category']=='fee') {
    $fee=$fee+$row['amount'];
  }
  elseif ($row['category']=='payment transfers') {
    $tr=$tr+$row['amount'];
  }
  elseif ($row['category']=='other') {
    $other=$other+$row['amount'];
  }
  elseif ($row['category']=='travel') {
    $travel=$travel+$row['amount'];
  }
}

}
echo '<script>
window.onload = function myfunction2() {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title:{
		text: "Email Categories",
		horizontalAlign: "left"
	},
	data: [{
		type: "doughnut",
		startAngle: 60,
		//innerRadius: 60,
		indexLabelFontSize: 17,
		indexLabel: "{label} - #percent%",
		toolTipContent: "<b>{label}:</b> {y} (#percent%)",
		dataPoints: [

        { y: '. $travel.', label: "travel" },
        { y: '.$fee.', label: "Fee" },
        { y: '.$food.', label: "Food" },
        { y: '.$elec.', label: "Electricity" },
        { y: '.$tr.', label: "Payment transfers" },
        { y: '.$rec.', label: "Recharge" },
        { y: '.$other.', label: "Others" },
         {y: '.$vehicle.', label: "vehicle" },
          {y: '.$home.', label: "Home" }
		]
	}]
});
chart.render();

}
</script>';
?>
